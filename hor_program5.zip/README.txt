Compile: compileall
Executeables:
	enc_server.c:	enc_server [port]
	enc_client.c:	enc_client [plaintext] [key] [port]
	dec_server.c:	dec_server [port]
	dec_client.c:	dec_client [ciphertext] [key] [port]
	keygen.c:	keygen [key_length]
